# oysters > 2023-06-20 10:01am
https://universe.roboflow.com/oyster-obb/oysters-cjt7n

Provided by a Roboflow user
License: CC BY 4.0

